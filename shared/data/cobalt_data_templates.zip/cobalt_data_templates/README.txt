The files within the 'macro_enabled_templates' folder have additional help and data validation features that require excel macros be enabled.

If your company has a security policy that restricts opening macro enabled documents, use the 'no_macro_templates' folder instead.